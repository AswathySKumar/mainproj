package com.cg.controller;




import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.entity.BookingDetails;

import com.cg.entity.Hotel;
import com.cg.entity.RoomDetails;
import com.cg.entity.Users;
import com.cg.form.Admin;
import com.cg.service.HotelService;

@Controller
public class HotelController2 {
	static String userid1;
	static String hotelid1;
	static String roomid1;
	static int days1;
	
	
@Autowired
private HotelService hotelService;

@RequestMapping("/index")
public String welcome(){
	System.out.println("In Login Page");
	return "index";
}
//--------------------------------------------Register----------------------------------------------------------------------
@RequestMapping("/register")
public String getHomePage(Model model){
model.addAttribute("user",new Users());
return "register";
}


@RequestMapping(value="/save")
public String register(@ModelAttribute("user")@Valid Users user,BindingResult result,Model model){
	if(result.hasErrors()){
		System.out.println("Error");
          return "register";
		
	}
	else{
	user=hotelService.save(user);
	model.addAttribute("message","Registered successfully!!please login to continue");
	return "redirect:/register.html";
	}
	
}
//------------------------booking-----------------------------------------------------------------------------------
@RequestMapping(value="/booking")
public String getHomePageBooking(@RequestParam("rid") String roid,Model model){
	model.addAttribute("bookingdetails",new BookingDetails());
	roomid1=roid;
	String available=hotelService.checkRoomAvail(roid);
	String avail = available.toLowerCase();
	if(avail.equals("yes")){
		return "booking2";
	}
	else{
		model.addAttribute("message","Room not available");
		return "room";
	}
}

@RequestMapping(value="/book")
public String booking(@ModelAttribute("bookingdetails")@Valid BookingDetails booking,BindingResult result,@RequestParam("booked_from")String bfrom,@RequestParam("boooked_to")String bto,Model model) throws ParseException{
	SimpleDateFormat formatter=new SimpleDateFormat("yyyy-MM-dd");
	 Date date1=formatter.parse(bfrom);
	   SimpleDateFormat formatter2 = new SimpleDateFormat("dd-MMM-yyyy");
		String strdate=formatter2.format(date1);
	 System.out.println("String Date: "+strdate); 
	 
	 
	 SimpleDateFormat formatter1=new SimpleDateFormat("yyyy-MM-dd");
	 Date date2=formatter1.parse(bto);
	   SimpleDateFormat formatter3 = new SimpleDateFormat("dd-MMM-yyyy");
		String strdate2=formatter3.format(date2);
	// System.out.println("String Date: "+strdate); 
		long difference =  (date2.getTime()-date1.getTime())/86400000;

		if(result.hasErrors()){
		System.out.println("Error");
          return "booking2";
		
	}
		else if(difference<0){
			return "errordate";
		}
		else if(difference==0){
				difference=1;
			
			
		}
				else
					if(difference>0){}
	 

	int bookingid=hotelService.save(booking,strdate,strdate2,hotelid1,roomid1,userid1,difference);
	
	model.addAttribute("message","Congratulations!!! your booking is  Successfull");
	 return "booking2";
					}
			
		
	

//--------------------------------------------------------------------------------------------------------------------------------
@RequestMapping(value= "/login")
public String getHomePagelogin(Model model){
	
model.addAttribute("log",new Users());
return "login2";
}

@RequestMapping(value="/logincheck")
public String login(@ModelAttribute("log")Users user,@RequestParam("user_id")String userid,Model model){
	System.out.println("your userid is"+userid);
	userid1=userid;
	Users hotelList=hotelService.check(user);
	if(hotelList==null)
	{
		model.addAttribute("message","invalid credentials");
		return "login2";
	}
	else{
	//model.addAttribute("message"," successfully loggedin!");
	return "loginsuccess";
	}
}
//------------------------------------------------------------------------------------------------------------------------------------
@RequestMapping(value= "/hotels")
public String getHotels(Model model){
	model.addAttribute("hotels",hotelService.loadAllhotels());
	model.addAttribute("hotel",new Hotel());
	return "hotel";
	

}
//-----------------------------------------------------------------------------------------------------------------------------------

@RequestMapping(value= "/rooms")
public String getrooms(@RequestParam("hid") String id,Model model){
	hotelid1=id;
	model.addAttribute("rooms",hotelService.loadAllrooms(id));
	model.addAttribute("hotel",new Hotel());
	return "room";

}

@RequestMapping(value="/loginchecck")
public String loginn(){
	return "loginsuccess";
	
}

@RequestMapping(value= "/bookingstatus")
public String getbookingstatus(Model model){
	model.addAttribute("status",hotelService.bookingstatus(userid1,hotelid1,roomid1));
	model.addAttribute("bookingdetails",new BookingDetails());
	return "bookingsuccess";
	

}








//----------------------*********ADMIN LOGIC***********--------------------------------


@RequestMapping(value="loginprocess")
public String valCredentials(@ModelAttribute("login") Admin admin){	
	String uName= admin.getUserName();
	String pass= admin.getPassword();
	boolean res = hotelService.validate(uName, pass);
	if(res==false){
		return "error";
	}
	else{
		return "adminhome";
	}
	
}

@RequestMapping(value="adminlogin")
public String login(Model model){	
	model.addAttribute("login", new Admin());
	return "adminlogin";
}
@RequestMapping(value="viewhoteldetails")
public String viewAllHotels(Model model){	
	model.addAttribute("hotelList", hotelService.viewAllHotels());
	model.addAttribute("hotel", new Hotel());
	return "viewhotels";	
}
@RequestMapping("viewrooms")
public String viewRooms(Model model){
	model.addAttribute("hotelList", hotelService.viewAllHotels());
	model.addAttribute("hotel", new Hotel());
	return "viewrooms";	
}	
@RequestMapping("editrooms")
public String editRooms(Model model,@RequestParam(value="hotelid") String hid){
	//model.addAttribute("hid", hid);
	model.addAttribute("roomList", hotelService.viewRooms(hid));
	return "editrooms";		
}
@RequestMapping("addhotels")
public String addHotels(Model model){
	model.addAttribute("hoteldummy",new Hotel());
	return "addhotels";	
}



@RequestMapping("hotelsuccess")
public String addHotels(Model model,@ModelAttribute("hoteldummy")@Valid Hotel hotel,BindingResult result){
	String hid = hotel.getHotel_id();
	boolean res = hotelService.hotelCheck(hid);
	
	if(result.hasErrors()){
		System.out.println("Error");
	      return "addhotels";
		
	}
	
	else{
	
	if(res==false){
		Hotel hotel_dum = hotelService.addHotels(hotel);	
		return "hotelsuccess";
	}
	else{
		return "hotelerror";
	}
}
}

@RequestMapping(value="loginproccess")
public String view(){
	return "adminhome";
	
}

@RequestMapping(value="bookings")
public String viewAllBookings(Model model){	
	model.addAttribute("hotelList", hotelService.viewAllHotels());
	model.addAttribute("hotel", new Hotel());
	return "bookings";	
}

@RequestMapping(value="bookingsdetails")
public String viewBookingDetails(Model model,@RequestParam(value="hotelid")String hid){
	model.addAttribute("bookingsList", hotelService.viewAllBookings(hid));
	return "bookingsdetails";
}

@RequestMapping("update")
public String update(){
	return "update";
}
///////**************************************************************


@RequestMapping("updatehotel")
public String updateHotel(Model model){
	model.addAttribute("hotelList", hotelService.viewAllHotels());
	model.addAttribute("hotel", new Hotel());
	//model.addAttribute("hoteldummy",new Hotel());
	return "updatehotel";
	
}
@RequestMapping("updatehoteledit")
public String updateHotel2(Model model, @RequestParam(value="hotelid")String hid){
	model.addAttribute("hotelList", hotelService.viewAllHotels());
	model.addAttribute("hoteldummy", new Hotel());
	model.addAttribute("hList", hotelService.getHotelById(hid));
	model.addAttribute("message","readonly");
	return "updatehoteledit";
	
}

@RequestMapping("info")
public String updatelast(@ModelAttribute("hoteldummy")@Valid Hotel hoteldummy,BindingResult result,Model model){
	if(result.hasErrors()){
		System.out.println("Error in Updating Hotel");
		return "updatehoteledit";
	}
	else{
	int res = hotelService.updateHotel(hoteldummy);
	return "info";
	}
}
//*******************************************************************************

@RequestMapping("deletehotel")
public String deleteHotel(Model model){
	model.addAttribute("hotelList", hotelService.viewAllHotels());
	model.addAttribute("hotel", new Hotel());
	//model.addAttribute("hoteldummy",new Hotel());
	return "deletehotel";

}

@RequestMapping("deletehotelsucess")
public String deletesucess(@RequestParam(value="hotelid")String hid){
	
	int res = hotelService.deletehotel(hid);
	if (res>0){
		int res2 = hotelService.deleteRoomByHotelId(hid);
		return "deletehotelsuccess";}
	else
		return "error";
}

//**************************UPDATING ROOMS************************************

@RequestMapping("updaterooms")
public String updaterooms(){
	return "updaterooms";
}

@RequestMapping("addrooms1")
public String addrooms1(Model model){
	model.addAttribute("hotelList", hotelService.viewAllHotels());
	//model.addAttribute("roomdummy", new RoomDetails());
	return "addrooms1";
	
}



@RequestMapping("addrooms2")
public String addrooms2(Model model,@RequestParam(value="hotelid")String hid){
	//model.addAttribute("hotelList", hotelService.viewAllHotels());
	model.addAttribute("hotelId", hid);
	model.addAttribute("roomdummy", new RoomDetails());
	return "addrooms2";
	
}

@RequestMapping("roomsuccess")
public String roomVerify(@ModelAttribute("roomdummy")@Valid RoomDetails room,BindingResult result, Model model){
	//System.out.println(room.get);
	String rid = room.getRoom_id();
	boolean res = hotelService.roomCheck(rid);
	//System.out.println(res);
	if(result.hasErrors()){
		System.out.println("Error");
	      return "addrooms2";
		
	}
	else{
	if(res==false){
		RoomDetails room_dum = hotelService.addrooms(room);	
		return "roomsuccess";
	}
	else{
		return "roomerror";
	}
	}
}


@RequestMapping("modifyrooms")
public String modifyrooms(Model model){
	model.addAttribute("roomList", hotelService.viewAllRooms());
	return "modifyrooms";
	
}

@RequestMapping("editroom")
public String modifyRooms(@RequestParam("roomid")String rid,Model model){
	model.addAttribute("modifiedroom", new RoomDetails());
	model.addAttribute("rDetails", hotelService.getRoomById(rid));
	return "modifingpage";
}
@RequestMapping("modifysuccess")
public String successmodify(@ModelAttribute("modifiedroom")@Valid RoomDetails room,BindingResult result,Model model){
	//String rid = room.getRoom_id();
	//System.out.println(rid);
	if(result.hasErrors()){
		System.out.println("Error");
	      return "modifingpage";
	}
	else{
	int res = hotelService.updateRoom(room);
	return "modifysuccess";

	}
}

//************************ DELETING A ROOM *********************************
@RequestMapping("deleterooms")
public String deleteroom(Model model){
	model.addAttribute("roomList", hotelService.viewAllRooms());
	return "deleterooms";
}

@RequestMapping("deleteroomsuccess")
public String deletedroom(@RequestParam("roomid")String rid){
	
	int res = hotelService.deleteroom(rid);
	return "deleteroomsuccess";
	
}

//********************BOOKINGS OF SPECIFIC DATE************************
@RequestMapping("bookingsofdate")
public String bookingsOfDate(){
	return "bookingsofdate";
	
}

@RequestMapping("bookingsdate")
public String bookingdate(@RequestParam("bookingdate") String date,Model model) throws ParseException{
	System.out.println(date);
	SimpleDateFormat formatter=new SimpleDateFormat("yyyy-MM-dd");
	 Date date1=formatter.parse(date);
	   SimpleDateFormat formatter2 = new SimpleDateFormat("dd-MMM-yyyy");
		String strdate=formatter2.format(date1);
	 System.out.println("String Date: "+strdate);
	 /*SimpleDateFormat formatter3=new SimpleDateFormat("dd-MMM-yyyy");
	 Date date3 = formatter3.parse(strdate);
	 System.out.println(new SimpleDateFormat("dd-MMM-yyyy").format(date3.getTime()));
	 System.out.println("Date 3 id: "+date3);
	 Date lastdate = new SimpleDateFormat("dd-MMM-yyyy").parse(strdate);
	 System.out.println("last date is "+lastdate);*/
	model.addAttribute("BookingsList", hotelService.getBookingsByDate(strdate));
	return "date";
	
}





}
