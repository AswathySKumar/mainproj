package com.cg.service;



import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.dao.HotelRepository;
import com.cg.entity.BookingDetails;
import com.cg.entity.Hotel;
import com.cg.entity.RoomDetails;
import com.cg.entity.Users;

@Service
@Transactional
public class HotelServiceImpl implements HotelService{
	@Autowired
	private HotelRepository hotelRepository;

	

	@Override
	public Users save(Users user) {
		
		return hotelRepository.save(user) ;
	}

	@Override
	public int save(BookingDetails booking,String strdate,String strdate2,String hotelid1,String roomid1,String userid1,long difference) {
		// TODO Auto-generated method stub
		return hotelRepository.save(booking,strdate,strdate2,hotelid1,roomid1,userid1,difference);
	}


	@Override
	public Users check(Users user) {
		// TODO Auto-generated method stub
		return hotelRepository.check(user);
	}

	@Override
	public List<Hotel> loadAllhotels() {
		// TODO Auto-generated method stub
		return hotelRepository.loadAllhotels();
	}

	@Override
	public List<RoomDetails> loadAllrooms(String id) {
		// TODO Auto-generated method stub
		return hotelRepository.loadAllrooms(id);
	}

	@Override
	public List<BookingDetails> bookingstatus(String userid1, String hotelid1,
			String roomid1) {
		// TODO Auto-generated method stub
		return hotelRepository.bookingstatus(userid1, hotelid1, roomid1);
	}

	//------------------------ADMIN-------------------------------------
	
	@Override
	public boolean validate(String uName, String pass) {
		if (uName.equals("admin")&& pass.equals("admin")){
			System.out.println("bdzvchg");
			return true;
		}
		else{
			System.out.println("djhbvjh");
			return false;
		}
	}

	@Override
	public List<Hotel> viewAllHotels() {
		return hotelRepository.viewAllHotels();
	}

	@Override
	public List<RoomDetails> viewRooms(String hid) {
		return hotelRepository.viewRooms(hid);
	}

	@Override
	public Hotel addHotels(Hotel hotel) {
		
		return hotelRepository.addHotels(hotel);
	}

	@Override
	public boolean hotelCheck(String hid) {
		return hotelRepository.hotelCheck(hid);
	}

	@Override
	public List<BookingDetails> viewAllBookings(String hid) {
		
		return hotelRepository.viewAllBookings(hid);
	}

	@Override
	public Hotel getHotelById(String hid) {
		return hotelRepository.getHotelById(hid);
	}

	@Override
	public int updateHotel(Hotel hdummy) {
		
		return hotelRepository.updateHotel(hdummy);
	}

	@Override
	public int deletehotel(String hid) {
		
		return hotelRepository.deleteHotel(hid);
	}

	@Override
	public boolean roomCheck(String rid) {
		
		return hotelRepository.roomcheck(rid);
	}

	@Override
	public RoomDetails addrooms(RoomDetails room) {
		return hotelRepository.addrooms(room);
	}

	@Override
	public List<RoomDetails> viewAllRooms() {
		
		return hotelRepository.viewAllRooms();
	}

	@Override
	public RoomDetails getRoomById(String rid) {
		
		return hotelRepository.getRoomById(rid);
	}

	@Override
	public int updateRoom(RoomDetails room) {
		
		return hotelRepository.updateRooms(room);
	}

	@Override
	public int deleteroom(String rid) {
		
		return hotelRepository.deleteroom(rid);
	}

	@Override
	public int deleteRoomByHotelId(String hid) {
		
		return hotelRepository.deleteRoomByHotelId(hid);
	}

	@Override
	public List<BookingDetails> getBookingsByDate(String date) {
		
		return hotelRepository.getBookingsByDate(date);
	}

	@Override
	public String checkRoomAvail(String roid) {
		
		String avail= hotelRepository.checkRoomAvail(roid);
		return avail;
	}


	

}
